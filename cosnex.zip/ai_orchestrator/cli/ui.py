"""Shared Cosnex CLI branding and Rich presentation helpers."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.panel import Panel
from rich.status import Status
from rich.text import Text
from rich.theme import Theme


APP_NAME = "Cosnex"
BRAND_ICON = "◉─✦─◉"
TAGLINE = "Navigate the code cosmos. Connect every nexus."

COSNEX_THEME = Theme(
    {
        "cosnex.brand": "bold bright_cyan",
        "cosnex.accent": "bright_magenta",
        "cosnex.muted": "grey62",
        "cosnex.success": "bold green",
        "cosnex.warning": "bold yellow",
        "cosnex.error": "bold red",
        "cosnex.path": "cyan underline",
    }
)

console = Console(theme=COSNEX_THEME)


def print_brand_header(*, subtitle: str | None = None) -> None:
    """Render a compact branded header for one-shot CLI commands."""
    title = Text(f"{BRAND_ICON}  {APP_NAME}", style="cosnex.brand", justify="center")
    body = Text(subtitle or TAGLINE, style="cosnex.muted", justify="center")
    console.print(
        Panel(
            body,
            title=title,
            subtitle="AI engineering workspace",
            border_style="bright_cyan",
            padding=(0, 2),
        )
    )


@contextmanager
def cosnex_indexing_animation() -> Iterator[Status]:
    """Animate a small cosmos-to-nexus sequence while repository indexing runs."""
    message = (
        f"[cosnex.brand]{BRAND_ICON}[/cosnex.brand] "
        "[cosnex.accent]Mapping the code cosmos[/cosnex.accent] "
        "[cosnex.muted]• linking the nexus...[/cosnex.muted]"
    )
    with console.status(
        message,
        spinner="moon",
        spinner_style="bright_cyan",
        refresh_per_second=12.0,
    ) as status:
        yield status
