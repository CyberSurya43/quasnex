"""Plan command - Generate task packets for every stage."""

from __future__ import annotations

from pathlib import Path

from rich.text import Text

from ai_orchestrator.core import Orchestrator
from ai_orchestrator.cli.ui import console, print_brand_header


def handle_plan(project_dir: Path) -> None:
    """Handle the plan command."""
    print_brand_header(subtitle="Turn the roadmap into executable stages")
    orchestrator = Orchestrator(project_dir)
    with console.status("[cosnex.muted]Generating stage plans...[/cosnex.muted]", spinner="dots"):
        run_dir = orchestrator.plan()
    console.print("[cosnex.success]✓ Plan generated[/cosnex.success] ", end="")
    console.print(Text(str(run_dir), style="cosnex.path"))
